
<meta charset="UTF-8" />

<style type="text/css">

body {
    background-color: blue;
  }

    #infos {
    background-color: blue;
    color: red;
    text-align: center;
    font-size: 250%;
    height: 90%;
    
    }

  #pied {
  height:10%;
  text-align: center;
}





</style>

<body>
<?php
$_GET['site']=0
?>

<?php require('head.php') ?>


<?php $bd = new SQLite3('Site.db');
if (isset($_POST['pseudo']))
{
        $statement = $bd->prepare('UPDATE Informations SET pseudo=:pseudo,mdp=:mdp,nom=:nom,prenom=:prenom WHERE id_infos=:id;');
        $statement->bindValue(':id',$_SESSION['id']);
        $statement->bindValue(':pseudo',htmlspecialchars($_POST['pseudo']));
        $statement->bindValue(':mdp',htmlspecialchars($_POST['mdp']));
        $statement->bindValue(':nom',htmlspecialchars($_POST['nom']));
        $statement->bindValue(':prenom',htmlspecialchars($_POST['prenom']));
        $result=$statement->execute();
        $reqq=$bd->prepare("SELECT pseudo,mdp,nom,prenom,url FROM Informations where id_infos=:id;");
        $reqq->bindValue(':id',$_SESSION['id']);
        $resultt=$reqq->execute();
        $idi=$_SESSION['id'];
        while ($p=$resultt->fetchArray())
      {
        $pseudo= $p['pseudo'];
        $mdp = $p['mdp'];
        $nom = $p['nom'];
        $prenom = $p['prenom'];
        $url = $p['url'];
     }
        $_SESSION = array();
        session_unset();
        session_destroy();
        session_start();
        $_SESSION['id'] = $idi;
        $_SESSION['pseudo'] = $pseudo;
        $_SESSION['mdp'] = $mdp;
        $_SESSION['nom'] = $nom;
        $_SESSION['prenom'] = $prenom;
        $_SESSION['image'] = $url;
        header('location:index.php?site=1');
         
}
else {?>



<div id="infos">
 <form action="modifier.php" method="post">
                 <br><br>

                Pseudo :
                <input type="text"  name="pseudo" value="<?php echo $_SESSION['pseudo'] ?>"/><br><br>

                Mot de passe :
                <input type="password"  name="mdp" value="<?php echo $_SESSION['mdp'] ?>"/><br><br>
                   
                Nom :
                  <input type="text"  name="nom" value="<?php echo $_SESSION['nom'] ?>"/><br><br>

                Prenom: 
                  <input type="text"  name="prenom" value="<?php echo $_SESSION['prenom'] ?>"/><br><br>
                 
                  <input type="submit" value="Envoyer" />
             
</form>

</div>

<div id="pied">

<?php require('pied.php') ?>

</div>
             

<?php } ?>