<?php session_start(); ?>



<html>
<meta charset="UTF-8" />

<title>Scores personnels pour Tetris</title>

<style type="text/css">

body {
		background-color: blue;
	}


#head {
	text-align: center;
	background-color : white;
	height:10%;
}


#infos {
	text-align : center;
	background-color : blue;
	height:90%;
}

#autres {
	background-color: white;
	width: 20%;
	float: left;

}


table, th, td {
	border: 1px solid red;
}

table {
  width: 80%;
}


#pied {
	background-color : blue;
	height:10%;
	text-align: center;
}


#couleur {
	color : red;
	font-size: 200%
}


#couleurt {
	color: red;
	font-size: 250%;
	text-decoration: underline;
}


</style>



<body>

<?php require('headsp.php') ?>


<br><br>
<br><br>
<br><br>


<div id="infos">



	<table>
		<tr>
			<th style="color:red">Pseudo</th>
			<th style="color:red">Score</th>
		</tr>
		
		<?php
		$bd = new SQLite3('Site.db');
		$statement=$bd->prepare("SELECT DISTINCT score FROM Scoresp where id_infos=:idinfos and id_jeu=:idjeu order by score DESC LIMIT 10;");
		$statement->bindValue(':idinfos',htmlspecialchars($_SESSION['id']));
        $statement->bindValue(':idjeu',htmlspecialchars($_GET['idj']));
        $result=$statement->execute();



        while ($d =$result->fetchArray())
        {
        	$score=$d['score']?>
        	<tr>
			<td style="color:red"><?php echo $_SESSION['pseudo']?></td>
			<td style="color:red"><?php echo $d['score']?></td>

		</tr>


		
       <?php } ?>





	</table>

	<br><br>
	<br><br>
	<br><br>
	<br><br>


	<form action="ajouter.php?idjeu=1" method="post">
                 <br><br>
                   
                <p id="couleurt" style="color:red">Ajouter un nouveau score :</p>
                  <input type="number"  name="score" /><br><br>
                 
                  <input type="submit" value="Envoyer" />
             
</form>





</div>


<div id="pied">

<?php require('pied.php') ?>


</div>


</body>


</html>