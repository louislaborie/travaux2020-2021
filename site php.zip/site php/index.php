

<html>
    <head>
        <meta charset="UTF-8" />
        <meta name="author" content="Louis LABORIE" />
        <meta name="description" content="Tetris projet" />
        <meta name="keywords" content="tetris, scores, comparaison" />
         
        <title>Your games scores</title>
 
<style type="text/css">
    body { background-color : #333;
            color: black;
    font-family: 'Lucida Grande', Arial, Verdana;
    text-align: center;
    display : block;
            }
   
    div {border-radius: 0.6em;
    margin: 5px;
    padding: 5px;}
    
    #main {background-image: url("tetris.jpg");
			height : 85%;
             
            }
    #main_g{background-color : white;
            float: left;
            width: 45%;
            }
    #main_d {background-color : white;
            float: right;
            width: 45%;
            }
    
a:hover{
    color: black;
    text-decoration: none;
}

#pied {
  background-color : #333;
  height:10%;
  text-align: center;
}
 
</style>

<style>


#couleurt { color: red;
    font-size:150%;
    font-weight: bolder;
}


#bleut { color: blue}

</style>
</head>
    <body>


<?php
$_GET['site'] = 1
?>


<?php require("head.php"); ?>

<div id="main">
    



        <img src="kisspng-tyrannosaurus-google-chrome-t-rex-runner-dinosaur-dino-google-5b401c955c8c68.2834355615309282773791.png" width="460" height="345">
		
		
		


		
		
		
    </div>
<div id="pied">
<?php require("pied.php"); ?>

</div>

</html>
