<?php session_start();?>
<html>
<meta charset="UTF-8" />
</html>

<?php

$_SESSION = array();
session_unset();
session_destroy();
header("location:index.php?site=1");

?>
