<?php session_start(); ?>
<html>
<meta charset="UTF-8" />
</html>
<?php 
if (isset($_POST['score']))
    {
  
    $bd = new SQLite3('Site.db');
        $statement = $bd->prepare("INSERT INTO Scoresp (id_infos,id_jeu,score) VALUES(:idinf,:idjeu,:score);");
        $statement->bindValue(':idinf',htmlspecialchars($_SESSION['id']));
        $statement->bindValue(':idjeu',htmlspecialchars($_GET['idjeu']));
        $statement->bindValue(':score',htmlspecialchars($_POST['score']));
        $result=$statement->execute();
    header('location:scoresperso.php?site=9');

  }
 ?>