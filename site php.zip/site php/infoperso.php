<?php session_start();?>

<html>



<meta charset="UTF-8" />
<title>Informations personnelles</title>


<style type="text/css">
	body {
		background-color: blue;
	}




#infos {
	text-align : center;
	background-color : blue;
	height:90%;
}


#cercle {
    width: 130px;
    height: 130px;
    float: left;
    border-radius: 20px;
    background: green;
    overflow:hidden;
}



#pied {
	background-color : blue;
	height:10%;
	text-align: center;
}


#couleur {
	color : red;
	font-size: 200%
}


#couleurt {
	color : red;
	font-size: 250%;
	text-decoration: underline;
}








</style>





<?php require("headinf.php"); ?>







<br><br>




<div id="infos">

	<img src="<?php echo $_SESSION['image'] ?>" width="130" height="130">
	<br><br>
	<p id="couleur">Pseudo : <?php echo $_SESSION['pseudo'] ?> </p>
	<br><br>
	<p id="couleur">Mot de passe : <?php echo $_SESSION['mdp']  ?></p>
	<br><br>
	<p id="couleur">Prenom : <?php echo $_SESSION['prenom']  ?></p>
	<br><br>
	<p id="couleur">Nom : <?php echo $_SESSION['nom']  ?></p>


</div>


<div id="pied">
	<?php require("pied.php")?>
	


</div>

</html>















