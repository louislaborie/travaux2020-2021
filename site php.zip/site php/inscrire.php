<html>
<meta charset="UTF-8" />

<title>S'inscrire</title>

<style type="text/css">
  body {
    background-color: blue;
  }

	#infos {
		background-color: blue;
		color: red;
    text-align: center;
    font-size: 250%;
    height: 90%;
    
	}

  #pied {
  height:10%;
  text-align: center;
}





</style>

<body>

<?php require('head.php') ?>

<?php $url='images/unnamed.png' ?>

<?php 
if (isset($_POST['pseudo']))
    {
  
    $bd = new SQLite3('Site.db');

    	   
        $statement = $bd->prepare("INSERT INTO Informations (pseudo,mdp,nom,prenom,url) VALUES(:pseudo,:mdp,:nom,:prenom,:url);");
        $statement->bindValue(':pseudo',htmlspecialchars($_POST['pseudo']));
        $statement->bindValue(':mdp',htmlspecialchars($_POST['mdp']));
        $statement->bindValue(':nom',htmlspecialchars($_POST['nom']));
        $statement->bindValue(':prenom',htmlspecialchars($_POST['prenom']));
        $statement->bindValue(':url',htmlspecialchars($url));
        $result=$statement->execute();
        header('location:index.php?site=1');
    

  }
 ?>

<div id="infos">
 
 <form action="inscrire.php?site=4" method="post">
                 <br><br>

                Pseudo :
                <input type="text"  name="pseudo" /><br><br>

                Mot de passe :
                <input type="password"  name="mdp" /><br><br>
                   
                Nom :
                  <input type="text"  name="nom" /><br><br>

                Prenom: 
                  <input type="text"  name="prenom" /><br><br>
                 
                  <input type="submit" value="Envoyer" />
             
</form>

</div>

<div id="pied">
  <?php require('pied.php') ?>

</div>


</body>


</html>