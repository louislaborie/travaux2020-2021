





<html>
<meta charset="UTF-8" />



<style type="text/css">

ul {
  list-style-type: none;
  margin: 12;
  padding: 10;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
  border-right: 3px solid #bbb;
}

li a  {
  display: block;
  color: white;
  text-align: center;
  padding: 15px 30px;
  font-size: 1.5em;
  text-decoration: none;
}

li a:hover {
  color:white;
  background-color:black;
}

</style>

<body>



<ul>
    <li><a href="index.php?site=1">Accueil</a></li>
    <li><a href="scoresg.php?site=13">Scores globaux</a></li>
    
    <?php
    if (isset($_SESSION['prenom']))
    {   
      if ($_GET['site'] == 5)
    {
    echo "<li><a style='background-color:blue' href='infoperso.php?site=5'>Informations Personnelles</a></li>";
    }
    else
    {
     echo "<li><a href='infoperso.php?site=5'>Informations Personnelles</a></li>";
    }
      if ($_GET['site'] == 6)
    {
    echo "<li><a style='background-color:blue' href='scorest.php?idj=1&site=6'>Tetris</a></li>";
    }
    else
    {
     echo "<li><a href='scorest.php?idj=1&site=6'>Tetris</a></li>";
    }
      if ($_GET['site'] == 7)
    {
    echo "<li><a style='background-color:blue' href='scoresd.php?idj=2&site=7'>Dino</a></li>";
    }
    else
    {
     echo "<li><a href='scoresd.php?idj=2&site=7'>Dino</a></li>";
    }
      if ($_GET['site'] == 8)
    {
    echo "<li><a style='background-color:blue' href='scoresp.php?idj=3&site=8'>Pacman</a></li>";
    }
    else
    {
     echo "<li><a href='scoresp.php?idj=3&site=8'>Pacman</a></li>";
    }
    echo  "<li><a href='deco.php'>Se déconnecter</a></li>";
    } 

    else
    {?>
      <li><a href="connexion.php">Se connecter</a></li>
      <li><a href="inscrire.php">S'inscrire</a></li>
  <?php  } ?>


</ul>

</body>

</html>



    

    




