<?php session_start() ?>

<?php
if (isset($_FILES['monfichier']) AND $_FILES['monfichier']['error'] == 0)
        {
        if ($_FILES['monfichier']['size'] <= 200000000)
        {
            $infosfichier = pathinfo($_FILES['monfichier']['name']);
            $extension_upload = $infosfichier['extension'];
            $extensions_autorisees = array('png','jpeg','jpg','gif','webp','jfif');
                if (in_array($extension_upload, $extensions_autorisees))
                {
    $dossier='images/';
    if ($_POST['nomf']=='')
                {$nom='Image'.$_SESSION['id'].'.'.$extension_upload;}
    else {$nom='Image'.$_SESSION['id'].'.'.$extension_upload;}
      move_uploaded_file($_FILES['monfichier']['tmp_name'],$dossier.$nom);
        $nomb='images/'.$nom;
        $bd = new SQLite3('Site.db');
        $req=$bd->prepare("UPDATE Informations SET url=:url where id_infos=:id");
        $req->bindValue(':id',$_SESSION['id']);
        $req->bindValue(':url',htmlspecialchars($nomb));
        $result=$req->execute();
        $_SESSION['image']=$nomb;
        header('location:index.php?site=1');
                        
                 
        
        }
        }
    }
?>