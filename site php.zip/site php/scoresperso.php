<?php session_start(); ?>



<html>

<meta charset="UTF-8" />
<title>Scores personnels</title>

<style type="text/css">

body {
		background-color: blue;
	}




#infos {
	text-align : center;
	background-color : blue;
	height:90%;
}





table, th, td {
	border: 1px solid red;
}

table {
  width: 80%;
}



#pied {
	background-color : white;
	height:10%;
	text-align: center;
}


#couleur {
	color : red;
	font-size: 200%
}


#couleurt {
	color : red;
	font-size: 250%;
	text-decoration: underline;
}


</style>



<body>


<?php require("headsp.php"); ?>




<br><br>


<div id="infos">
	


	


</div>



<div id="pied">


<?php require('pied.php'); ?>



</div>










</body>


</html>


















</body>





</html>


