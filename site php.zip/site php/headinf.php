





<html>
<meta charset="UTF-8" />



<style type="text/css">



ul {

  list-style-type: none;
  margin: 12;
  padding: 10;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
  border-right: 3px solid #bbb;
}

li a  {
  display: block;
  color: white;
  font-size: 150%;
  text-align: center;
  padding: 15px 17px;
  text-decoration: none;
}

li a:hover {
  color:white;
  background-color:black;
}

</style>

<body>



<ul>
    <li><a href="index.php?site=1">Accueil</a></li>
    <li><a href="jouer.php?site=2">Jouer</a></li>
    <li><a href="scoresg.php?site=13">Scores globaux</a></li>
    <?php
    if (isset($_SESSION['prenom']))
    {?>
        <li><a href="modifier.php">Modifier vos informations</a></li>
        <li><a href="ajouterimage.php?site=0">Ajouter une image</a></li>
        <li><a href="scoresperso.php?site=9">Scores personnels</a></li>
        <li><a href="deco.php">Se déconnecter</a></li>
    <?php }

    else
    {?>
        <li><a href="connexion.php">Se connecter</a></li>
        <li><a href="inscrire.php">S'inscrire</a></li>

    <?php } ?>


</ul>

</body>

</html>



    

    




