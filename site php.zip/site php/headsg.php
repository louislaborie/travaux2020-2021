





<html>
<meta charset="UTF-8" />



<style type="text/css">

ul {
  list-style-type: none;
  margin: 12;
  padding: 10;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
  border-right: 3px solid #bbb;
}

li a  {
  display: block;
  color: white;
  text-align: center;
  padding: 15px 30px;
  font-size: 1.5em;
  text-decoration: none;
}

li a:hover {
  color:white;
  background-color:black;
}

</style>

<body>



<ul>
    <li><a href="index.php?site=1">Accueil</a></li>
    <li><a href="scoresperso.php?site=9">Scores personnels</a></li>
    <?php
      if ($_GET['site'] == 10)
    {
    echo "<li><a style='background-color:blue' href='scorestg.php?idj=1&site=10'>Tetris</a></li>";
    }
    else
    {
     echo "<li><a href='scorestg.php?idj=1&site=10'>Tetris</a></li>";
    }
      if ($_GET['site'] == 11)
    {
    echo "<li><a style='background-color:blue' href='scoresdg.php?idj=2&site=11'>Dino</a></li>";
    }
    else
    {
     echo "<li><a href='scoresdg.php?idj=2&site=11'>Dino</a></li>";
    }
      if ($_GET['site'] == 12)
    {
    echo "<li><a style='background-color:blue' href='scorespg.php?idj=3&site=12'>Pacman</a></li>";
    }
    else
    {
     echo "<li><a href='scorespg.php?idj=3&site=12'>Pacman</a></li>";
    }

    
    if (isset($_SESSION['prenom']))
    {?>
        <li><a href="infoperso.php?site=5">Informations personnelles</a></li>
        <li><a href="deco.php">Se déconnecter</a></li>
    <?php } 

    else
    {?>
      <li><a href="connexion.php?site=3">Se connecter</a></li>
      <li><a href="inscrire.php?site=4">S'inscrire</a></li>
  <?php  } ?>


</ul>

</body>

</html>



    

    




