<?php require('head.php')?>


<form action="saveimage.php" method="post" enctype="multipart/form-data">
<input type="file" name="monfichier" />
<input type="submit" value="Ajouter" />
</form>