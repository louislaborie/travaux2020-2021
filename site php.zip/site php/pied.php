<html>
<meta charset="UTF-8" />

<style type="text/css">

#footer {height : 100%;
    background-color : #333;}


 #couleurt {
	color : white;
	font-size: 250%;
	text-decoration: underline;
}


</style>


<body>





 <div id="footer">
 	<?php
 	  if (isset($_SESSION['prenom']))
 	  {?>
 	  	<p id="couleurt" style="text-decoration: none">Bon jeu, <?php echo $_SESSION['prenom']?></p>
 	 <?php }
 	  else
 	  {?>
 	  	<p id="couleurt"> COPYRIGHT : 2020 LABORIE INC  </p>
 	  <?php } ?>
      





</div>




</body>



</html>





 