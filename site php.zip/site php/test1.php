<html>
    <head>
        <meta charset="UTF-8" />
    <head>
    <body>
     Votre pseudo est : <?php
	 $a="Blizzard";
	 
	 
	 
	 

	 echo $a; ?>
	 
	 
	 
	 <?php
     $L=[['Bob','Mewtwo'],['Alice','Pikachu'],['Fildrong','PasDeCheveux'],['EstbonàCS','Foennikss']];
     foreach ($L as $val){echo 'pseudo :'.$val[1].'  mdp: '.$val[0].'<br>';}
     ?>
	 
	 
    </body>
</html>