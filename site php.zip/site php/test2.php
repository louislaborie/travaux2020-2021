<?php
$i = 5;
while ($i < 9) {
    echo $i;
    $i++;
}
?>