<?php
	 $pseudo = $_POST['pseudo'];
	 $mdpt = $_POST['mdp'];
	 $bd = new SQLite3('Site.db');
     $req = $bd->prepare('SELECT id_infos FROM Informations where pseudo=:pseudo and mdp=:mdp;');
     $req->bindValue(':pseudo',$pseudo);
     $req->bindValue(':mdp',$mdpt);
     $result= $req->execute();
     $reqq=$bd->prepare('SELECT nom FROM Informations where id_infos=:id;');
     $reqq->bindValue(':id',$result);
     $nom = $reqq->execute();
     $reqqq=$bd->prepare('SELECT prenom FROM Informations where id_infos=:id;');
     $reqqq->bindValue(':id',htmlspecialchars($result));
     $prenom = $reqq->execute();

     echo $result;
     echo $nom;
     echo $prenom;


?>
