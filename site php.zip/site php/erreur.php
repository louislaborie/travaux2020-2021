<html>
<meta charset="UTF-8" />



<title>Erreur de connexion</title>

<style type="text/css">


#police {
	font-size: 150%;
	text-decoration: underline;

}

</style>

<body>



<h2 id="police"><strong>Erreur de connexion ! Veuillez retourner à l'accueil et réessayer</strong></h2>


<br><br>
<br><br>
<br><br>

<li>

<a href="index.php" id="police"><strong>Accueil</strong></a>

</li>


</body>


</html>