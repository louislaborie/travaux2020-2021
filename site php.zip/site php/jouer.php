<html>
<meta charset="UTF-8" />



<title>Jouer aux jeux</title>



<style type="text/css">

body {
	background-color: blue;
}



#head {
	background-color: blue;
	height: 15%;
}


#police {

	color: red;
	text-decoration: underline;
	font-size: 250%;
	text-align: center;
}



#reste {
	background-color: blue;
	height: 75%;
	background-image: url("pacman-pixabay.jpg");
}

#rested {
	float: right;
}

#pied {
	height: 10%;
	text-align: center;
}




</style>


<body>



<?php require('head.php') ?>




<div id="reste">
	<div id="rested">
		<img src="kisspng-tetris-clip-art-tetromino-video-games-polyomino-5ba2f1d0bf3ce1.4858179715374053927833.png" width="420" height="320">


	</div>
	<a href="https://www.tetrisgratuit.fr/" id="police" style="text-align:center" target="_blank">Tetris</a>
	<br><br>
	<br><br>
	<a href="https://dino-chrome.com/fr" id="police" style="text-align:center" target="_blank">Jeu du dino</a>
	<br><br>
	<br><br>
	<a href="https://www.google.com/search?rlz=1C1VDKB_frFR928FR928&sxsrf=ALeKk001iMOVC6xjbXT2jt8aAxf0d4trMg%3A1605785555956&ei=01e2X4XzOa-UlwSMr7GAAQ&q=pacman&oq=pacman&gs_lcp=CgZwc3ktYWIQAzIECCMQJzIECCMQJzIKCC4QsQMQFBCHAjIHCAAQFBCHAjIFCAAQsQMyAggAMgIIADICCAAyAggAMgIIADoECAAQR1CyIliyImDgJGgAcAJ4AIABjwGIAY8BkgEDMC4xmAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=psy-ab&ved=0ahUKEwjFqJetwY7tAhUvyoUKHYxXDBAQ4dUDCA0&uact=5" id="police" style="text-align:center" target="_blank">Pacman</a>



</div>

<div id="pied">
	<?php require('pied.php') ?>


</body>



</html>










