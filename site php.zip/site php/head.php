<?php session_start() ?>




<html>
<meta charset="UTF-8" />



<style type="text/css">

ul {
  list-style-type: none;
  margin: 12;
  padding: 10;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
  border-right: 3px solid #bbb;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 15px 30px;
  font-size: 150%;
  text-decoration: none;
}

li a:hover {
  color:white;
  background-color:black;
}

.active {
  background-color: blue;
}

li a:active{
  background-color:red;
}

</style>

<body>



<ul>
    <?php
    if ($_GET['site'] == 1)
    {
    echo "<li><a style='background-color:blue' href='index.php?site=1'>Accueil</a></li>";
    }
    else
    {
      echo "<li><a href='index.php?site=1'>Accueil</a></li>";
    }

    if ($_GET['site'] == 2)
    {
    echo "<li><a style='background-color:blue' href='jouer.php?site=2'>Jouer</a></li>";
    }
    else
    {
      echo "<li><a href='jouer.php?site=2'>Jouer</a></li>";
    }?>
    <li><a href="scoresg.php?site=13">Scores globaux</a></li>
    <?php
       if (isset($_SESSION['prenom']))
        {?>
        <li><a href="scoresperso.php?site=9">Scores personnels</a></li>
        <li><a href="infoperso.php">Profil</a></li>
        <li><a href="deco.php">Se déconnecter</a></li>
        <li style="float:right"><img style="float:right" src="<?php echo $_SESSION['image'] ?>" width="120" height="100"></li>
          <?php }

        else
          {
          if ($_GET['site'] == 3)
          {
            echo "<li><a style='background-color:blue' href='connexion.php?site=3'>Se connecter</a></li>";
          }
          else
          {
            echo "<li><a href='connexion.php?site=3'>Se connecter</a></li>";
          }
          if ($_GET['site'] == 4)
          {
            echo "<li><a style='background-color:blue' href='inscrire.php?site=4'>S'inscrire</a></li>";
          }
          else
          {
            echo "<li><a href='inscrire.php?site=4'>S'inscrire</a></li>";
          }

        }
   
?>




</ul>

</body>

</html>



    

    




