<html>
<meta charset="UTF-8" />

<title>Connexion</title>

<style type="text/css">
  body {
    background-color:blue;
  }

#main {
	height:85%;
  background-color: blue;
  color: red;
  text-align: center;
  font-size: 250%;
}

#pied {
  background-color : blue;
  height:10%;
  text-align: center;
}



</style>


<body>

<?php require("head.php"); ?>

<div id="main">



<form action="identification.php" method="post">
                 <br><br>

                Pseudo :
                <input type="text"  name="pseudo" /><br><br>

                Mot de passe :
                <input type="password"  name="mdp" /><br><br>

              	<input type="submit" value="Connexion" />



</form>

</div>

<div id="pied">
  <?php require('pied.php') ?>

</body>

</html>


