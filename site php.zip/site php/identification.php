






<html>
<meta charset="UTF-8" />

<body>






<?php
	 $bd = new SQLite3('Site.db');
     $req=$bd->prepare("SELECT id_infos FROM Informations where pseudo=:pseudo and mdp=:mdp;");
     $req->bindValue(':pseudo',htmlspecialchars($_POST['pseudo']));
     $req->bindValue(':mdp',htmlspecialchars($_POST['mdp']));
     $result=$req->execute();
     while ($d =$result->fetchArray())
     {$id=$d['id_infos'];}
     
     $reqq=$bd->prepare("SELECT nom,prenom,url FROM Informations where id_infos=:id;");
     $reqq->bindValue(':id',$id);
     $resultt=$reqq->execute();
     while ($p=$resultt->fetchArray())
     {
     	$nom = $p['nom'];
     	$prenom = $p['prenom'];
        $url = $p['url'];
     }

     
         if ($id <> 0)

      { 	

         	header("Location: index.php?site=1");
         	session_start();
         	$_SESSION['id']=$id;
			$_SESSION['pseudo']=$_POST['pseudo'];
			$_SESSION['mdp']=$_POST['mdp'];
			$_SESSION['prenom']=$prenom;
			$_SESSION['nom']=$nom;
            $_SESSION['image']=$url;

			}

	
		else {
			header("Location: erreur.php");
		}

	
	

    
?>


 




 </body>




 </html>     
